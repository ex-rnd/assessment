-- James Kilonzo: top_students.sql

SELECT ID, NAME 
FROM STUDENT
ORDER BY SCORE DESC, ID ASC
LIMIT 3;
